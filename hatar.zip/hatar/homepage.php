<html>
<head>
    <title>
        HOUSE RENTAL SYSTEM
    </title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <link href="css/jquery-ui-themes-1.10.4/themes/ui-lightness/jquery-ui.css" rel="stylesheet">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script src="js/jquery-ui-1.10.4/jquery-1.10.2.js"></script>
    <script src="js/jquery-ui-1.10.4/ui/jquery-ui.js"></script>
    <style>
        .scrolling-wrapper {
            overflow-x: scroll;
            overflow-y: hidden;
            white-space: nowrap;
        .card {
            display: inline-block;
        }
        }
    </style>
    <style>
        body {
            background: linear-gradient(90deg, rgba(177, 64, 200, 1) 0%,
            rgba(109, 9, 121, 1) 35%, rgba(45, 1, 62, 1) 100%);
        }
        .glow {
            font-size: 70px;
            color: #ffffff;
            text-align: center;
            -webkit-animation: glow 1s ease-in-out infinite alternate;
            -moz-animation: glow 1s ease-in-out infinite alternate;
            animation: glow 1s ease-in-out infinite alternate;
        }
        @-webkit-keyframes glow {
            from {
                text-shadow: 0 0 10px #eeeeee, 0 0 20px #000000, 0 0 30px #000000, 0 0 40px #000000,
                0 0 50px #9554b3, 0 0 60px #9554b3, 0 0 70px #9554b3;
            }
            to {
                text-shadow: 0 0 20px #eeeeee, 0 0 30px #ff4da6, 0 0 40px #ff4da6, 0 0 50px #ff4da6,
                0 0 60px #ff4da6, 0 0 70px #ff4da6, 0 0 80px #ff4da6;
            }
        }
    </style>
</head>
<body bgcolor="green">
<center>
    <img class src="A5.jpeg" alt="Picture four" style="width:30%;height:200px;">
    <img class src="A6.jpeg" alt="Picture five" style="width:35%;height:200px;">
    <img class src="A7.jpeg" alt="Picture six" style="width:34%;height:200px;">
</center>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-lg-12 col-sm-12 badge-priamary" style="min-height: 500px">
            <div class="card">
                <div class="card-header bg-primary">
                    <center>
                        <h1 style="color:red;font-size:40px;">HOMEPAGE</h1>
                    </center>
                </div>
                <div class="row">
                        <div class="column">
                            <a href="login.php" target="_blank"><button type="button" class="btn btn-primary"><img height="50" width="50" src="icon.jpeg">SIGN IN</button></a>
                            <a href="" ><button type="button" class="btn btn-success"><img height="50" width="50" src="icon.jpeg">About Us</button></a>
                            <a href="" ><button type="button" class="btn btn-info"><img height="50" width="50" src="icon.jpeg">Contact us</button></a>
                        </div>
                        
                    </div>
            </div>
            <div>
            <h1 class="glow">HOUSELAND<br>A HOUSE RENTAL SYSTEM</h1>
        </div>
<div>
            <h5 style="color:yellow;font-size:40px;">OUR HOUSES</h5>
        </div>
<div>
            <h5 style="color:yellow;font-size:40px;">Family HOUSES:</h5>
        </div>
<div class="scrolling-wrapper">
                        
                            <button type="button" class="btn btn-dark">
                                <img style="height:300px;width:70%;" src="duplex-1.jpeg">AHMED MANSION(DUPLEX)<br>10000TK(per month)</button>
                        
                        
                        <button type="button" class="btn btn-dark">
                            <img style="height:300px;width:70%;" src="triplex-1.jpeg">Prasad(TRIPLEX)<br>15000TK(per month)</button>
                        
                       
                        <button type="button" class="btn btn-dark">
                            <img style="height:300px;width:70%;" src="quadplex-2..jpeg">RAHIM VILA(QUADPLEX)<br>20000TK(per month)</button>
                        
                        
                            <button type="button" class="btn btn-dark">
                            <img style="height:300px;width:70%;" src="triplex-2.jpeg">SHARIF BHABAN(TRIPLEX)<br>16000TK(per month)</button>
                        
                        
                            <button type="button" class="btn btn-dark">
                            <img style="height:300px;width:70%;" src="duplex-2.jpg">JAFAR MANSION(DUPLEX)<br>11300TK(per month)</button>
                        
                        
                            <button type="button" class="btn btn-dark">
                            <img style="height:300px;width:70%;" src="quadplex-1.jpeg">CHOWDHURY VILA(QUADPLEX)<br>26000TK(per month)</button>
                    
                    </div>

<div>
            <h5 style="color:yellow;font-size:40px;">BACHELOR(Male) HOUSES:</h5>
        </div>
<div class="scrolling-wrapper">
                        
                            <button type="button" class="btn btn-dark">
                                <img style="height:300px;width:70%;" src="bachelor(male1).jpg">AZZAK MANSION<br>4000TK(per month)</button>
                        
                        
                            <button type="button" class="btn btn-dark">
                                <img style="height:300px;width:70%;" src="bachelor(male2).jpg">PARAJ VILA<br>5000TK(per month)</button>
                        
                        
                            <button type="button" class="btn btn-dark">
                                <img style="height:300px;width:70%;" src="bachelor(male3).jpg">MANSHAH VILA<br>6000TK(per month)</button>
                        
                        
                            <button type="button" class="btn btn-dark">
                                <img style="height:300px;width:70%;" src="bachelor(male4).jpg">MITSAN BHABAN<br>4000TK(per month)</button>
                        
                        
                            <button type="button" class="btn btn-dark">
                                <img style="height:300px;width:70%;" src="bachelor(male5).jpg">ATAUR MANSION<br>5000TK(per month)</button>
                        
                        
                            <button type="button" class="btn btn-dark">
                                <img style="height:300px;width:70%;" src="bachelor(male6).jpg">ANWAR VILA<br>6000TK(per month)</button>
                       
                    </div>
<div>
            <h5 style="color:yellow;font-size:40px;">BACHELOR(Female) HOUSES:</h5>
        </div>
<div class="scrolling-wrapper">
                        
                            <button type="button" class="btn btn-dark">
                                <img style="height:300px;width:70%;" src="bachelor(female1).jpg">KARI MANSION<br>3000TK(per month)</button>
                        
                        
                            <button type="button" class="btn btn-dark">
                                <img style="height:300px;width:70%;" src="bachelor(female2).jpg">ABANA Prasad<br>4000TK(per month)</button>
                        
                        
                            <button type="button" class="btn btn-dark">
                                <img style="height:300px;width:70%;" src="bachelor(female3).jpg">OBITA VILA<br>5000TK(per month)</button>
                       
                        
                            <button type="button" class="btn btn-dark">
                                <img style="height:300px;width:70%;" src="bachelor(female4).jpg">ANJITA BHABAN<br>3000TK(per month)</button>
                        
                        
                            <button type="button" class="btn btn-dark">
                                <img style="height:300px;width:70%;" src="bachelor(female5).jpg">UBARNA MANSION<br>4000TK(per month)</button>
                        
                        
                            <button type="button" class="btn btn-dark">
                                <img style="height:300px;width:70%;" src="bachelor(female6).jpg">ABNHAZ VILA<br>5000TK(per month)</button>
                       
                    </div>

            </div>
        </div>

<center>
    <img src="flag.png" alt="Picture two" style="width:100%;height:100px;">
</center>
<footer>
    <img class src="A5.jpeg" alt="Picture four" style="width:30%;height:200px;">
    <img class src="A6.jpeg" alt="Picture five" style="width:35%;height:200px;">
    <img class src="A7.jpeg" alt="Picture six" style="width:34%;height:200px;">
</footer>


</body>
</html>